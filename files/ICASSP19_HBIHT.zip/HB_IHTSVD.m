clear

m=50;n=40;
r0=3;
M=randn(m,r0)*randn(r0,n);
s=1000;
R=randperm(m*n)';
S=sort(R(1:s));
Sc=sort(R(s+1:end));

r=r0;


%% DRCC
[U,~,V]=svd(M);
VU2=kron(V(:,r0+1:end),U(:,r0+1:end));     
H=VU2(Sc,:);
svd_H=svd(H);
ls_H0=svd_H(end);
p=1-s/m/n;
q=(m-r)*(n-r)/m/n;
ls_H=sqrt(q*(1-p))-sqrt(p*(1-q));

niters=1e3;
errs=[];
alltime=tic;


%% SVT
delta=1.2*m*n/s;
tau=5*sqrt(m*n);
X=M;
X(Sc)=0;
k0=ceil(tau/delta/norm(X));
Y=k0*delta*X;
err1=zeros(niters,1);
for iter=1:niters
    err1(iter)=norm(X-M,'fro');
    X=singular_value_soft_thresholding(Y,tau);
    Y(S)=Y(S)+delta*(M(S)-X(S));
end
errs=[errs,err1];


%% SVP - fixed step size
X=M;
X(Sc)=0;
err=zeros(niters,1);
alpha_SVP=m*n/(1.2*s);
for iter=1:niters
    err(iter)=norm(X-M,'fro');
    df=zeros(size(X));
    df(S)=X(S)-M(S);
    X=singular_value_hard_thresholding(X-alpha_SVP*df,r);
end
errs=[errs,err];


%% SVP - fixed step size optimal
X=M;
X(Sc)=0;
err=zeros(niters,1);
alpha_SVP_opt=2/(1+ls_H0^2);
for iter=1:niters
    err(iter)=norm(X-M,'fro');
    df=zeros(size(X));
    df(S)=X(S)-M(S);
    X=singular_value_hard_thresholding(X-alpha_SVP_opt*df,r);
end
errs=[errs,err];


%% IHTSVD
X=M;
X(Sc)=0;
err=zeros(niters,1);
for iter=1:niters
    err(iter)=norm(X-M,'fro');
    X(S)=M(S);            
    X=singular_value_hard_thresholding(X,r);
end
errs=[errs,err];


%% HB - fixed step size optimal
X=M;
X(Sc)=0;
Xp=X;
err=zeros(niters,1);
alpha_HB=(2/(1+ls_H0))^2;
beta_HB=((1-ls_H0)/(1+ls_H0))^2;
for iter=1:niters
    err(iter)=norm(X-M,'fro');
    df=zeros(size(X));
    df(S)=X(S)-M(S);
    Xn=singular_value_hard_thresholding(X-alpha_HB*df,r)+beta_HB*(X-Xp);
    Xp=X;
    X=Xn;
end
errs=[errs,err];


%% HB - fixed step size estimated
tic
X=M;
X(Sc)=0;
Xp=X;
err=zeros(niters,1);
alpha_HBe=(2/(1+ls_H))^2;
beta_HBe=((1-ls_H)/(1+ls_H))^2;
for iter=1:niters
    err(iter)=norm(X-M,'fro');
    df=zeros(size(X));
    df(S)=X(S)-M(S);
    Xn=singular_value_hard_thresholding(X-alpha_HBe*df,r)+beta_HBe*(X-Xp);
    Xp=X;
    X=Xn;
end
errs=[errs,err];
toc


%% AltMin
tic
T=55;
Rs=randi(2*T+1,s,1);
M1=zeros(size(M));
M1(S)=M(S)*m*n/s;
[U,~,~]=svd(M1,'econ');
U=U(:,1:r);
err=zeros(niters,1);
X=M;
X(Sc)=0;
for t=1:T    
    err(t)=norm(X-M,'fro');
    
    Hv=kron(eye(n),U);
    HvS=Hv(S,:);
    vV=(HvS'*HvS+0*eye(size(HvS,2)))\(HvS'*M(S));
    V=reshape(vV,r,n)';
    
    Hu=kron(V,eye(m));
    HuS=Hu(S,:);
    vU=(HuS'*HuS+0*eye(size(HuS,2)))\(HuS'*M(S));
    U=reshape(vU,m,r);
    X=U*V';
end
err(T+1:niters)=0;
errs=[errs,err];
toc


toc(alltime)
%% Display results
Cs=[1-ls_H0^2,(1-ls_H0)/(1+ls_H0),(1-ls_H0^2)/(1+ls_H0^2)];
bounds=Cs.^((1:niters)');
bounds=bounds*errs(1,1)./[5e2,1e1,5e2];

figure(1)
ax = gca;
semilogy(errs,'LineWidth',1)
hold on
ax.ColorOrderIndex = 4;
semilogy(bounds,'--','LineWidth',1)
hold off
leg=legend('SVT', ...
    'IHT ($\alpha_k=\frac{mn}{1.2s}$)', ...    
    'IHT ($\alpha_k=\frac{2}{L+\mu}$)*', ...  
    'HB-IHT (optimal)*',...
    'HB-IHT (estimated)',...
    'AM', ...  
    'location','best');
set(leg,'Interpreter','latex')
xlabel('k','Interpreter','latex')
ylabel('$||X^{(k)}-M||_F$','Interpreter','latex')
ylim([1e-12,1e3])
xlim([1,500])


