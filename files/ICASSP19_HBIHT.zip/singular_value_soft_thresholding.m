function Y = singular_value_soft_thresholding(X,t)
    [U,S,V]=svd(X,'econ');
    x=diag(S);
    s=max(0,x-t);
    Y=U*(s.*V');
end