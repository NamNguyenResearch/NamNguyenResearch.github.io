clear

m=50;n=40;
r0=3;
M=randn(m,r0)*randn(r0,n);
s=1000;
R=randperm(m*n)';
S=sort(R(1:s));
Sc=sort(R(s+1:end)); 

r=3;


%% DRCC
[U,~,V]=svd(M);
VU2=kron(V(:,r0+1:end),U(:,r0+1:end));     
H=VU2(Sc,:);
svd_H=svd(H);
ls_H0=svd_H(end);
Cs=[1-ls_H0^2,1-ls_H0];
p=1-s/m/n;
q=(m-r)*(n-r)/m/n;
ls_H=sqrt(q*(1-p))-sqrt(p*(1-q));

niters=1e3;
errs=[];
alltime=tic;


%% SVT
delta=1.2*m*n/s;
tau=5*sqrt(m*n);
X=M;
X(Sc)=0;
k0=ceil(tau/delta/norm(X));
Y=k0*delta*X;
err1=zeros(niters,1);
for iter=1:niters
    err1(iter)=norm(X-M,'fro');
    X=singular_value_soft_thresholding(Y,tau);
    Y(S)=Y(S)+delta*(M(S)-X(S));
end
errs=[errs,err1];


%% SVP-NewtonD
X=M;
X(Sc)=0;
err=zeros(niters,1);
delta_SVP=m*n/s/1.2;
Ms=vec(M(S));
for iter=1:niters
    err(iter)=norm(X-M,'fro');
    Y=X;
    Y(S)=Y(S)+delta_SVP*(M(S)-X(S));
    [U,~,V]=svd(Y,'econ');
    H=[];
    for i=1:r
        ui=U(:,i);
        vi=V(:,i);
        uv=ui*vi';
        H=[H,vec(uv(S))];
    end
    sig=(H'*H)\(H'*Ms);
    X=U(:,1:r)*(sig.*V(:,1:r)');
end
errs=[errs,err];


%% NIHT
X=M;
X(Sc)=0;
Y=X;
err=zeros(niters,1);
for iter=1:niters
    err(iter)=norm(X-M,'fro');
    [U,Sig,V]=svd(Y,'econ');
    sig=diag(Sig);
    X=U(:,1:r)*(sig(1:r).*V(:,1:r)');    
    Pu=U(:,1:r)*U(:,1:r)';
    dX=zeros(size(X));
    dX(S)=M(S)-X(S);
    PuX=Pu*dX;
    delta_IHT=norm(PuX,'fro')^2/norm(PuX(S),2)^2;
    Y=X;
    Y(S)=Y(S)+delta_IHT*dX(S);
end
errs=[errs,err];


%% IHTSVD
X=M;
X(Sc)=0;
err=zeros(niters,1);
for iter=1:niters
    err(iter)=norm(X-M,'fro');
    X(S)=M(S);            
    X=singular_value_hard_thresholding(X,r);
end
errs=[errs,err];


%% NAG - fixed step size optimal
X=M;
X(Sc)=0;
Y=X;
beta_NAG=(1-ls_H0)/(1+ls_H0);
err=zeros(niters,1);
for iter=1:niters
    err(iter)=norm(X-M,'fro');   
    Xn=singular_value_hard_thresholding(Y,r);
    Y=Xn+beta_NAG*(Xn-X);
    Y(S)=M(S);
    X=Xn;
end
errs=[errs,err];


%% NAG - estimate sequence
X=M;
X(Sc)=0;
Y=X;
err=zeros(niters,1);
for iter=1:niters
    err(iter)=norm(X-M,'fro');
    Xn=singular_value_hard_thresholding(Y,r);
    Y=Xn+(iter-1)/(iter+2)*(Xn-X);
    Y(S)=M(S);
    X=Xn;
end
errs=[errs,err];


%% Adaptive NAG
tic
X=M;
X(Sc)=0;
Y=X;
err=zeros(niters,1);
k=1;
curr=norm(X(S)-M(S));
for iter=1:niters
    err(iter)=norm(Y-M,'fro'); 
    prev=curr;
    curr=norm(X(S)-M(S));
    if iter>1 && curr>prev
        k = 1;
    end
    Xn=singular_value_hard_thresholding(Y,r);
    Y=Xn+(k-1)/(k+2)*(Xn-X);
    Y(S)=M(S);
    X=Xn;
    k=k+1;
end
errs=[errs,err];
toc


%% AltMin
tic
T=55;
Rs=randi(2*T+1,s,1);
M1=zeros(size(M));
M1(S)=M(S)*m*n/s;
[U,~,~]=svd(M1,'econ');
U=U(:,1:r);
err=zeros(niters,1);
X=M;
X(Sc)=0;
for t=1:T    
    err(t)=norm(X-M,'fro');
    
    Hv=kron(eye(n),U);
    HvS=Hv(S,:);
    vV=(HvS'*HvS+0*eye(size(HvS,2)))\(HvS'*M(S));
    V=reshape(vV,r,n)';
    
    Hu=kron(V,eye(m));
    HuS=Hu(S,:);
    vU=(HuS'*HuS+0*eye(size(HuS,2)))\(HuS'*M(S));
    U=reshape(vU,m,r);
    X=U*V';
end
err(T+1:niters)=0;
errs=[errs,err];
toc


toc(alltime)
%% Display results
bounds=Cs.^((1:niters)');
bounds=bounds*errs(1,1)./[1e1,1e2];

figure(1)
ax = gca;
semilogy(errs,'LineWidth',2)
hold on
ax.ColorOrderIndex = 4;
semilogy(bounds,'--','LineWidth',2)
hold off
leg=legend('SVT',...
    'SVP (adaptive step size)','NIHT (adaptive step size)','IHTSVD (unit step size)',...
    'NAG-IHT ($\beta_k=\frac{1-\sigma}{1+\sigma}$)*',...
    'NAG-IHT ($\beta_k=\frac{k-1}{k+2}$)',...
    'ARNAG-IHT', 'AM', ...
    'location','best');
set(leg,'Interpreter','latex')
xlabel('k','Interpreter','latex')
ylabel('$||Y^{(k)}-M||_F$','Interpreter','latex')
ylim([1e-12,1e3])
xlim([1,600])


