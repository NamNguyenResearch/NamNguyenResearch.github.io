function Y = singular_value_hard_thresholding(X,r)
    [U,S,V]=svd(X,'econ');
    s=diag(S);
    Y=U(:,1:r)*(s(1:r).*V(:,1:r)');
end