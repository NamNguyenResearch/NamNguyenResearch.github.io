%%% Minimizing f(x) = 1/2 * x' * A * x - b' * x
% To simplify the calculation, consider A as a diagional matrix
%
% eA - eigenvalues of A
% g_global - gamma at global solution
% g_local - gamma at local solution


clear
load('data.mat','n','eA','b','g_global','g_local')

niters=1e5;
LA=max(eA);
lA=min(eA);
f=@(x) (.5*x'*(eA.*x)-b'*x);

x_global=b./(eA-g_global);
P_global=eye(n)-x_global*x_global';
H_global=P_global.*eA*P_global;
eH_global=sort(eig(H_global),'descend');
eH_global=eH_global(abs(eH_global)>1e-10);
L_global=max(eH_global);
l_global=min(eH_global);
a_global=2/(L_global+g_global);     % step size

x_local=b./(eA-g_local);
P_local=eye(n)-x_local*x_local';
H_local=P_local.*eA*P_local;
eH_local=sort(eig(H_local),'descend');
eH_local=eH_local(abs(eH_local)>1e-10);
L_local=max(eH_local);
l_local=min(eH_local);
a_local=2/(L_local+g_local);        % step size


%% Local convergence
x0=x_local+1e-2*randn(n,1);
x0=x0/norm(x0);

% PGD - 1/L
x=x0;
a1=1/LA;
r1=max(abs(1-a1*l_local),abs(1-a1*L_local))/(1-a1*g_local);
log_x1=zeros(niters,1);
for i=1:niters
    log_x1(i)=norm(x-x_local);
    
    x=x-a1*(eA.*x-b);
    x=x/norm(x);
end

% PGD - optimal step size
x=x0;
a2=2/(L_local+l_local);
r2=(L_local-l_local)/(L_local+l_local-2*g_local);
log_x2=zeros(niters,1);
for i=1:niters
    log_x2(i)=norm(x-x_local);
    
    x=x-a2*(eA.*x-b);
    x=x/norm(x);
end

% PGD - backtracking
x=x0;
beta_bt=.8;
eta_bt=1;
log_xbt=zeros(niters,1);
for i=1:niters
    log_xbt(i)=norm(x-x_local);
    
    dg=eA.*x-b;
    while 1
        x_new=x-eta_bt*dg;
        x_new=x_new/norm(x_new);
        dG=(x-x_new)/eta_bt;
        
        % reduced
        if (dG'*(eA.*dG))/(dG'*dG) < 1/eta_bt
            break;
        end               
        
        eta_bt=eta_bt*beta_bt;
    end
    
    x=x_new;
    eta_bt=eta_bt*4;
end

% PGD - line search
x=x0;
log_xls=zeros(niters,1);
a_ls=.1;
for i=1:niters
    log_xls(i)=norm(x-x_local);
    
    r=eA.*x-b;
    ff=@(t) ( f((x-t*r)/norm(x-t*r)) );
    
    a1=x'*(eA.*x);
    b1=r'*(eA.*x);
    c1=r'*(eA.*r);
    d1=x'*x;
    e1=x'*r;
    f1=r'*r;
    g1=x'*b;
    h1=r'*b;

    t=linspace(0,a_ls*2,100);
    % Compute fa with less numerical error
    % fa=.5*(a1-2*t*b1+c1*t.^2)./(d1-2*t*e1+f1*t.^2)-(g1-t*h1)./sqrt(d1-2*t*e1+f1*t.^2);
    % Reason: try this 2+1e-16 > 2 vs 1e-16 > 0
    fa=.5*((c1*d1-f1*a1)*t.^2+2*t*(e1*a1-b1*d1))./(d1-2*t*e1+f1*t.^2)/d1...
        -(g1*(2*t*e1-f1*t.^2)./(sqrt(d1)+sqrt(d1-2*t*e1+f1*t.^2))...
        -t*h1*sqrt(d1))./sqrt(d1-2*t*e1+f1*t.^2)/sqrt(d1);
    [~,idx]=min(fa);
    a_ls=t(idx);
    
    x=x-a_ls*r;
    x=x/norm(x);
end


figure(1)
semilogy([log_x1,log_x2,log_xbt,log_xls])
hold on
semilogy(.1*r1.^(1:niters),'b--')
semilogy(.1*r2.^(1:niters),'r--')
hold off
ylabel('x')
ylim([1e-15,1])
legend('\alpha=1/L','\alpha=2/(\lambda_1+\lambda_{n-1})',...
    'backtracking','exact line search')
xlabel('t')
ylabel('$||x^{(t)}-x_*||$','interpreter','latex')



%% Test global
a=a_global*.5+a_local*.5;
r=max((a*L_global-1)/(1-a*g_global),(1-a*l_global)/(1-a*g_global));

x=x0;
log_x=zeros(niters,1);
log_f=log_x;
for i=1:niters
    log_x(i)=norm(x-x_global);
    log_f(i)=f(x);
    gi=(eA.*x-b)'*x;
    
    x=x-a*(eA.*x-b);
    x=x/norm(x);
end


figure(2)
semilogy(log_x)
hold on
semilogy(r.^(1:niters),'r--')
hold off
xlabel('t')
ylabel('$||x^{(t)}-x_{\star}||$','interpreter','latex')
ylim([2e-7,1e1])

figure(3)
loglog(abs(log_f-f(x_global)))
ylabel('$|f(x^{(t)})-f(x_{\star})|$','interpreter','latex')
ylim([1e-12,1e3])
xlabel('t')




