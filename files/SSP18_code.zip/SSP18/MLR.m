function [f, df, alpha_ma, beta_ma, d2f, P] = MLR(w, X, y, lambda, gradientCompute, dw)    

[D,N] = size(X);
C = length(w)/D;
W = reshape(w,D,C);
WX = W'*X; % C x N

XW_max = max(WX, [], 1); % 1 x N
eXW_max = exp(WX - ones(C,1) * XW_max); % C x N        
P = eXW_max ./ sum(eXW_max); % C x N    

y_index = sub2ind(size(WX), y, 1:N); % 1 x N
f = sum(XW_max) + sum(log(sum(eXW_max)));
f = f - sum(WX(y_index));
f = f/N + 0.5 * lambda * (w'*w);
% W2 = W(2:end, :);
% f = f/N + 0.5 * lambda * W2(:)' * W2(:);


if exist('gradientCompute', 'var')==1
    Q = P; P = P';
    Q(y_index) = Q(y_index) - 1;        
    Df = X*Q'; % D x C
    Df = Df/N + lambda*W;
%     Df(2:end, :) = Df(2:end, :) + lambda * W2;    
    df = Df(:);
    
    alpha_ma = 0;
    beta_ma = 0;
    d2f = zeros(numel(w));
    if gradientCompute==1
        if exist('dw', 'var')==1
            if numel(dw)<=1 % GD
                u = df'*df;
                M1 = X'*Df; % N x C
                g = sum(P.*M1,2);
                a = (sum(sum(M1.*P.*M1)) - g'*g)/N + lambda*u;
                alpha_ma = u/a;
            else % Momentum
                u = df'*df;
                v = dw'*df;
                t = dw'*dw;
                M1 = X'*Df; % N x C
                M2 = X'*reshape(dw,D,C); % N x C
                g = sum(P.*M1,2);
                h = sum(P.*M2,2);
                a = (sum(sum(M1.*P.*M1)) - g'*g)/N + lambda*u;
                b = (sum(sum(M1.*P.*M2)) - g'*h)/N + lambda*v;
                d = (sum(sum(M2.*P.*M2)) - h'*h)/N + lambda*t;
                alpha_ma = (d*u-b*v)/(a*d-b^2);
                beta_ma = (b*u-a*v)/(a*d-b^2);
            end
        end
    elseif gradientCompute==2
        for i=1:N
            pi = P(i,:)';
            xi = X(:,i);
            d2f = d2f + kron(diag(pi)-pi*pi', xi*xi');
        end
        d2f = d2f/N + lambda*eye(size(d2f));
    end
end
    
end