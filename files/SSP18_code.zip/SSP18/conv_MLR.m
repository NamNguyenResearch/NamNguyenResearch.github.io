clear
clc


%% Data
load('mnist.mat')
M = 10;        % nbags
n = 150;        % signal length
C = 3;          % number of digits including NONE
ndigits = 4;    % number of digits per bags
d = 28;         % image size dxd

for digit=0:C-2
    gg=digit;
    if digit==0
        gg=C-1;
    end
    cmd1=['train{',num2str(gg),'}=train',num2str(digit),';'];
    cmd2=['test{',num2str(gg),'}=test',num2str(digit),';'];
    eval(cmd1);
end

for i=1:C-1
    temp = double(train{i});
    max_cols = max(abs(temp) + 1, [], 1);
    train{i} = temp ./ max_cols;
end

X=cell(2*M,1);
Y=cell(size(X));
for m=1:length(X)
    dig=randi(C-1,ndigits,1);
    Y{m}=ones(1,n)*C;
    tmp=ones(d,n);
    for i=1:ndigits
        gg=dig(i);        
        [nc,~]=size(train{gg});
        idx=randi(nc);
        v=train{gg}(idx,:);
        offset=randi(d);    
        
        tmp(:,((i-1)*d+1:i*d)+offset)=tmp(:,((i-1)*d+1:i*d)+offset)+...
            double(reshape(v,d,d)');
        X{m}=tmp;    
        Y{m}((i-1)*d+d/2+offset)=gg;
    end
end


%% Setting parameters
% Flags
checkGradient = 0;
plotPredict = 1;
plotData = 1;

% Training params
gdf = 1;
gdb = 1;
gda = 1;
mf = 1;
ma = 1;
niters_nd = 1e2;
niters_gdf = 1e4;
niters_gdb = 1e4;
niters_gda = 1e4;
niters_mf = 1e4;
niters_ma = 5e3;
niters_adff = 5e4;

for m=1:2*M
    X{m} = [zeros(d,d/2) X{m} zeros(d,d/2-1)];
end
X_train = X(1:M);  y_train = Y(1:M); 
X_test = X(M+1:end); y_test = Y(M+1:end);

if plotData
    figure(1)
    for m=1:M
        ax(1)=subplot(2,1,1);
        imagesc(X_train{m}(:,d/2+1:end-d/2+1));
        c=colormap; colormap (1-c);
        ax(2)=subplot(2,1,2);
        temp = y_train{m};
        temp(find(temp==C-1)) = 0;
        temp(find(temp==C)) = -1;    
        stem(temp)
        linkaxes(ax,'x')
        xlim([1,n])    
        pause
    end
end

N = M*n;
X = zeros(d*d,N); XX_test = X;
y = zeros(1,N); yy_test = y;
for m=1:M
    for t=1:n
        temp = X_train{m}(:,t:t+d-1);
        X(:,(m-1)*n+t) = temp(:);
        temp = X_test{m}(:,t:t+d-1);
        XX_test(:,(m-1)*n+t) = temp(:);
    end
    y((m-1)*n+1:m*n) = y_train{m};
    yy_test((m-1)*n+1:m*n) = y_test{m};
end
D = size(X,1);

lambda = 1e-2;
w0 = randn(C*D,1)*1e-4;
l = lambda;
L = max(eig(X*X'))/2/N+lambda;
S=(L-l)/(L+l);
SS=(sqrt(L)-sqrt(l))/(sqrt(L)+sqrt(l));


%% Check gradient
if checkGradient
    gradCheckError = gradientChecking( w0, X, y, lambda )
    hessCheckError = hessianChecking( w0, X, y, lambda )
end


%% Momentum - adaptive step size
if ma
    w = w0;
    dw = randn(size(w))*1e-4;
    log_ma = zeros(niters_ma,1);
    logx_ma = zeros(niters_ma,numel(w));
    tic
    for iter=1:niters_ma
        [log_ma(iter),df,alpha_ma,beta_ma] = MLR(w, X, y, lambda, 1,dw);
        logx_ma(iter,:) = w;
        dw = - alpha_ma*df + beta_ma*dw;
        w = w + dw;
    end
    ma = toc

    % save solution
    ws = w;
    [fs,dfs,~,~,d2fs] = MLR(ws, X, y, lambda, 2);
    [V,D]=eig(d2fs);
    E=diag(D);
    [LL,II]=max(E);[ll,ii]=min(E);
    s=(LL-ll)/(LL+ll);
    ss=(sqrt(LL)-sqrt(ll))/(sqrt(LL)+sqrt(ll));
    log_ma = abs(log_ma(1:iter) - fs);
    logx_ma = logx_ma-ws';
    logx_maV = abs(logx_ma*V);
    norm_logx_ma = sqrt(sum(logx_maV'.^2));
end


%% GD - fixed step size
if gdf
    w = w0;
    alpha = 2/(L+l);
    log_gdf = zeros(niters_gdf,1);
    logx_gdf = zeros(niters_gdf,numel(w));
    tic
    for iter=1:niters_gdf
        [log_gdf(iter),df] = MLR(w, X, y, lambda, 1);
        logx_gdf(iter,:) = w;
        w = w - alpha*df;
    end
    gdf = toc
    log_gdf = abs(log_gdf(1:iter) - fs);
    logx_gdf = logx_gdf-ws';
    logx_gdfV = abs(logx_gdf*V);
    norm_logx_gdf = sqrt(sum(logx_gdfV'.^2));
end


%% GD - backtracking
if gdb
    w = w0;
    log_gdb = zeros(niters_gdb,1);
    logx_gdb = zeros(niters_gdb,numel(w));
    b_eta = 1;
    b_alpha = .2;
    b_beta = .5;
    tic
    for iter=1:niters_gdb
        [log_gdb(iter),df] = MLR(w, X, y, lambda, 1);
        logx_gdb(iter,:) = w;

        while 1
            b_eta = b_eta * b_beta;
            w_n = w - b_eta*df;
            f_n = MLR(w_n, X, y, lambda);
            if f_n <= log_gdb(iter) - b_alpha * b_eta * (df' * df)
                break;
            end
        end
        w = w - b_eta*df;
        b_eta = b_eta * 4;  
    end
    gdb = toc
    log_gdb = abs(log_gdb(1:iter) - fs);
    logx_gdb = logx_gdb-ws';
    logx_gdbV = abs(logx_gdb*V);
    norm_logx_gdb = sqrt(sum(logx_gdbV'.^2));
end


%% GD - adaptive step size
if gda
    w = w0;
    log_gda = zeros(niters_gda,1);
    logx_gda = zeros(niters_gda,numel(w));
    tic
    for iter=1:niters_gda
        [log_gda(iter),df,alpha_gda,~] = MLR(w, X, y, lambda, 1, 1);
        logx_gda(iter,:) = w;
        w = w - alpha_gda*df;
    end
    gda = toc
    log_gda = abs(log_gda(1:iter) - fs);
    logx_gda = logx_gda-ws';
    logx_gdaV = abs(logx_gda*V);
    norm_logx_gda = sqrt(sum(logx_gdaV'.^2));
end


%% Momentum - fixed step size   
if mf
    w = w0;
    dw = rand(size(w))*1e-4;
    sl1 = sqrt(L);
    sld = sqrt(l);
    alpha_mf = (2/(sl1+sld))^2;    
    beta_mf = ((sl1-sld)/(sl1+sld))^2;
    log_mf = zeros(niters_mf,1);
    logx_mf = zeros(niters_mf,numel(w));
    tic
    for iter=1:niters_mf
        [log_mf(iter),df,~,~] = MLR(w, X, y, lambda, 1);
        logx_mf(iter,:) = w;
        dw = - alpha_mf*df + beta_mf*dw;
        w = w + dw;
    end
    mf = toc
    log_mf = abs(log_mf(1:iter) - fs);
    logx_mf = logx_mf-ws';
    logx_mfV = abs(logx_mf*V);
    norm_logx_mf = sqrt(sum(logx_mfV'.^2));
end


%% Plot
kk = -15*log(10)/log(ss);
KK = -15*log(10)/log(SS);
k = -15*log(10)/log(s);
K = -15*log(10)/log(S);

%close all
figure(3)
labels={};
if ma, semilogy(logx_maV(:,II)); labels{end+1}='Momentum - adaptive step size'; end
hold on
if gdf, semilogy(logx_gdfV(:,II)); labels{end+1}='GD - fixed step size'; end
if gdb, semilogy(logx_gdbV(:,II)); labels{end+1}='GD - backtracking'; end
if gda, semilogy(logx_gdaV(:,II)); labels{end+1}='GD - adaptive step size'; end
if mf, semilogy(logx_mfV(:,II)); labels{end+1}='Momentum - fixed step size'; end
semilogy(logx_ma(1,II)*ss.^(1:kk), '--','LineWidth',4)
semilogy(1e-3*logx_ma(1,II)*s.^(1:k), '--','LineWidth',4)
semilogy(50*logx_ma(1,II)*SS.^(1:KK), '--','LineWidth',4)
semilogy(.03*logx_ma(1,II)*S.^(1:K), '--','LineWidth',4)
hold off
legend(labels, 'Location','best')
ylabel('$y^{(k)}_j = |U^T(w^{(k)}-w^*)|_j$','Interpreter','latex')
xlabel('$k$','Interpreter','latex')
ylim([1e-15, 1e2])
xlim([1, niters_gda*.7])


figure(2)
labels={};
if ma, semilogy(norm_logx_ma,'LineWidth',2); labels{end+1}='Momentum - adaptive step size'; end
hold on
if gdf, semilogy(norm_logx_gdf,'LineWidth',2); labels{end+1}='GD - fixed step size'; end
if gdb, semilogy(norm_logx_gdb,'LineWidth',2); labels{end+1}='GD - backtracking'; end
if gda, semilogy(norm_logx_gda,'LineWidth',2); labels{end+1}='GD - adaptive step size'; end
if mf, semilogy(norm_logx_mf,'LineWidth',2); labels{end+1}='Momentum - fixed step size'; end
semilogy(2*norm_logx_ma(1)*ss.^(1:kk), '--','LineWidth',4)
semilogy(.04*norm_logx_ma(1)*s.^(1:k), '--','LineWidth',4)
semilogy(5e1*norm_logx_ma(1)*SS.^(1:KK), '--','LineWidth',4)
semilogy(.3*norm_logx_ma(1)*S.^(1:K), '--','LineWidth',4)
hold off
legend(labels, 'Location','best')
ylabel('$||y^{(k)}||=||U^T(w^{(k)}-w^*)||$','Interpreter','latex')
xlabel('$k$','Interpreter','latex')
ylim([1e-13, 1e2])
xlim([1, niters_gda*.7])


%% Predict
if plotPredict
    [acc,pred] = predict(ws,XX_test,yy_test);
    figure(30)
    for m=1:M
        ax(1)=subplot(2,1,1);
        imagesc(X_test{m}(:,d/2+1:end-d/2+1));
        ax(2)=subplot(2,1,2);
        stem(pred((m-1)*n+1:m*n))
        linkaxes(ax,'x')
        xlim([1,n])
        pause
    end
end

















