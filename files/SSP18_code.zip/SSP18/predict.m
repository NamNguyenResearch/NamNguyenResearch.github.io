function [acc, pred] = predict(w, X, y)

D = size(X,1);
C = length(w)/D;
W = reshape(w, D, C);

WX = W' * X; % C x N
max_WX = max(WX, [], 1); % 1 x N
eXW_max = exp(WX - ones(C,1) * max_WX); % C x N
P = eXW_max ./ sum(eXW_max); % C x N

[~, pred] = max(P, [], 1);
acc = mean(pred == y);


end