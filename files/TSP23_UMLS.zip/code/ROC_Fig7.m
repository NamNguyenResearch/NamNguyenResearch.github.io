clear

lA1 = 5;
lA2 = 1;
x_unc1 = 0.7;
x_unc2 = 0.2;
scale_eta = 0.5;
niters = 1000;

colormap(parula)
fig(222)

x_unc = [x_unc1; x_unc2];
A = diag([lA1, lA2]);
b = x_unc .* diag(A);

f_gamma = @(g) ((g - lA2^2).^2 * (lA1 * b(1))^2 + ...
    (g - lA1^2).^2 * (lA2 * b(2))^2 - ...
    (g - lA1^2).^2 .* (g - lA2^2).^2);
gg = linspace(-10, 10, 1e4);

a = [1, -2 * (lA1^2 + lA2^2), ...
    lA1^4 + lA2^4 + 4 * lA1^2 * lA2^2 - lA1^2 * b(1)^2 - lA2^2 * b(2)^2, ...
    -2 * lA1^2 * lA2^2 * (lA1^2 + lA2^2 - b(1)^2 - b(2)^2), ...
    lA1^2 * lA2^2 * (lA1^2 * lA2^2 - lA1^2 * b(2)^2 - lA2^2 * b(1)^2)];
all_gamma = roots(a);
all_gamma = real(all_gamma(abs(imag(all_gamma)) < 1e-7));
all_x = [];
if norm(b) == 0
    all_x = eye(2); % eigenvectors of diagonal A
elseif b(1) == 0
    all_gamma = all_gamma(abs(all_gamma-lA1^2) > 1e-7);
    x2 = lA2 * b(2) ./ (lA2^2 - lA1^2);
    all_x = [[sqrt(1-x2^2), x2, lA1^2]; [-sqrt(1-x2^2), x2, lA1^2]];
elseif b(2) == 0
    all_gamma = all_gamma(abs(all_gamma-lA2^2) > 1e-7);
    x1 = lA1 * b(1) ./ (lA1^2 - lA2^2);
    all_x = [[x1, sqrt(1-x1^2), lA2^2]; [x1, -sqrt(1-x1^2), lA2^2]];
end
all_x = [all_x; [lA1 * b(1) ./ (lA1^2 - all_gamma), lA2 * b(2) ./ (lA2^2 - all_gamma), all_gamma]];

min_points = [];
max_points = [];
kkt_points = [];
for i = 1:size(all_x, 1)
    gm = all_x(i, 3);
    x = all_x(i, 1:2)';
    if lA1^2 * x(2)^2 + lA2^2 * x(1)^2 > gm
        min_points = [min_points, [x; gm]];
    elseif lA1^2 * x(2)^2 + lA2^2 * x(1)^2 < gm
        max_points = [max_points, [x; gm]];
    else
        kkt_points = [kkt_points, [x; gm]];
    end
end

f = @(x) .5 * norm(A*x-b)^2;
t = linspace(0, 2*pi, 1e3);
x1 = linspace(-2, 2, 1e3);
x2 = linspace(-2, 2, 1e3);
[X1, X2] = meshgrid(x1, x2);
Z = .5 * ((lA1 * X1 - b(1)).^2 + (lA2 * X2 - b(2)).^2);
vv = [linspace(0, 1, 20), linspace(1, 10, 10)];

plot(cos(t), sin(t), 'k', 'LineWidth', 1)
hold on
contour(X1, X2, Z, vv, '--')
plot(0, 0, 'k.', 'MarkerSize', 20)
plot(x_unc(1), x_unc(2), 'rp')
plot(max_points(1, :), max_points(2, :), 'h', 'MarkerSize', 10, 'LineWidth', 2)
xlim([-1.5, 1.5])
ylim([-1.5, 1.5])
axis square

%% PGD
x_star = min_points(1:2, 1);
plot(min_points(1, 1), min_points(2, 1), 'g*', 'MarkerSize', 10, 'LineWidth', 2)
plot(min_points(1, 2), min_points(2, 2), 'rd', 'MarkerSize', 10, 'LineWidth', 2)

gm = min_points(3, 1);
h = lA1^2 * x_star(2)^2 + lA2^2 * x_star(1)^2 - gm;
eta_max = 2 / (h + 2 * gm);

eta_max2 = eta_max;
if size(min_points, 2) >= 2
    x_star2 = min_points(1:2, 2);
    gm2 = min_points(3, 2);
    h2 = lA1^2 * x_star2(2)^2 + lA2^2 * x_star2(1)^2 - gm2;
    eta_max2 = 2 / (h2 + 2 * gm2);
end

eta = scale_eta * min(eta_max, eta_max2);
rho_eta = 1 - eta * (1 - eta * gm).^(-1) * h;
c_eta = norm(eye(2)-eta*A'*A) / (1 - eta * gm);
c0 = (1 - rho_eta) / 2 / c_eta / (c_eta + 1);
plot(x_star(1)+c0*cos(t), x_star(2)+c0*sin(t), 'g--', 'LineWidth', 2)

if size(min_points, 2) >= 2
    rho_eta2 = 1 - eta * (1 - eta * gm2).^(-1) * h2;
    c_eta2 = norm(eye(2)-eta*A'*A) / (1 - eta * gm2);
    c12 = (1 - rho_eta2) / 2 / c_eta2 / (c_eta2 + 1);
    plot(x_star2(1)+c12*cos(t), x_star2(2)+c12*sin(t), 'r--', 'LineWidth', 2)
end

marker_spacing = 10;
for t_index = 1:length(t)
    x0 = [cos(t(t_index)); sin(t(t_index))];
    x = x0;
    for k = 1:niters
        z = x - eta * A' * (A * x - b);
        x = z / norm(z);
    end
    is_converge = norm(x-x_star) < c0;

    if is_converge
        if mod(t_index, marker_spacing) == 0
            plot(x0(1), x0(2), 'g*', 'MarkerSize', 2, 'LineWidth', 2)
        else
            plot(x0(1), x0(2), 'g.', 'MarkerSize', 2, 'LineWidth', 2)
        end
    else
        if mod(t_index, marker_spacing) == 0
            plot(x0(1), x0(2), 'rd', 'MarkerSize', 2, 'LineWidth', 2)
        else
            plot(x0(1), x0(2), 'r.', 'MarkerSize', 2, 'LineWidth', 2)
        end
    end
end
hold off