function [ z ] = projection( x )
%     z = x / norm(x,2);

    n=length(x)/2;
    X=reshape(x,2,n);
    Z=X./sqrt(sum(X.*X,1));
    z=Z(:);
end

