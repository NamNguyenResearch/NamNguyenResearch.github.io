%%% Trung Vu - 03/20223

clear

%% Generate data
M = 800; % number of angles
N = 50; % number of sensors

nn = (0:N - 1) - (N - 1) / 2; % 1xN
theta_mm = (0:M - 1) / M * pi - pi / 2; %%% control beam only over 180 degrees (since this is a ula)
alpha_mm = sin(theta_mm); % 1xM
Phi = exp(-1j*pi*alpha_mm'*nn);

y = zeros(M, 1);
theta = 3; % sector beamforming angle in degree
m1 = round(M*theta/360+1);
m2 = round(M*(180 - theta)/360+1);
m3 = round(M*(180 + theta)/360+1);
m4 = round(M*(360 - theta)/360+1);
y((m2:m3)-20) = 1;

P = eye(M) - y * y' / (y' * y);
H_complex = Phi' * P * Phi;
L = max(abs(eig(H_complex(2:end, 2:end))));
f = @(x) abs(.5*x'*H_complex(2:end, 2:end)*x+real(H_complex(1, 2:end)*x)+.5*H_complex(1, 1));

[U, D] = eig(P);
[d, idx] = sort(diag(D), 'descend');
Q = U(:, idx(1:end-1));
A_complex = Q' * Phi(:, 2:end);
b_complex = -Q' * Phi(:, 1);

%% Algorithm
niters = 5e4;
x0 = exp(1j*randn(N-1, 1));

%% Backtracking
alpha_bt = .8;
beta_bt = .8;
eta_bt = 1;
log_bt = zeros(niters, 1);
log_count_bt = zeros(niters, 1);
log_bt_x = zeros(niters, N-1);
x = x0;
for k = 1:niters
    log_bt(k) = f(x);
    log_bt_x(k, :) = x;

    count = 2;
    df = H_complex(2:end, 2:end) * x + H_complex(2:end, 1);
    while 1
        x_new = exp(1j*angle(x-eta_bt*df));
        dG = (x - x_new) / eta_bt;

        % reduced
        if (dG' * H_complex(2:end, 2:end) * dG) / (dG' * dG) <= 1 / eta_bt
            break;
        end

        eta_bt = eta_bt * beta_bt;
        count = count + 1;
    end
    log_count_bt(k) = count;
    x = x_new;
    eta_bt = eta_bt / alpha_bt;
end
x_bt = [1; x];
y_bt = Phi * x_bt;
c_bt = (y' * y_bt) / (y' * y);
y_bt = y_bt / c_bt;

%% NAG - AR (with backtracking)
log_nag = zeros(niters, 1);
log_nag_x = zeros(niters, N-1);
log_count_nag = zeros(niters, 1);
x = x0;
x1 = x;
eta = 1;
theta_nag = 1;
alpha_nag = .8;
beta_nag = .8;
q = 0;
for k = 1:niters
    log_nag(k) = f(x1);
    log_nag_x(k, :) = x;

    % backtracking alpha
    count = 2;
    df = H_complex(2:end, 2:end) * x1 + H_complex(2:end, 1);
    while 1
        x_new = exp(1j*angle(x1-eta*df));
        dG = (x1 - x_new) / eta;

        % reduced
        if ((dG' * H_complex(2:end, 2:end) * dG)) / (dG' * dG) <= 1 / eta
            break;
        end

        eta = eta * beta_nag;
        count = count + 1;
    end
    log_count_nag(k) = count;
    eta = eta / alpha_nag;

    theta_nag_new = .5 * (q - theta_nag^2 + sqrt((theta_nag^2 - q)^2+4*theta_nag^2));
    beta = theta_nag * (1 - theta_nag) / (theta_nag^2 + theta_nag_new);
    dx = x_new - x;
    x1_new = x_new + beta * dx;
    x = x_new;
    theta_nag = theta_nag_new;

    dg = x1 - x_new;
    if dg' * dx > 0 % gradient scheme
        theta_nag = 1;
    end
    x1 = x1_new;
end
x_star_complex = x1;
x_nag = [1; x1];
y_nag = Phi * x_nag;
c_nag = (y' * y_nag) / (y' * y);
y_nag = y_nag / c_nag;

%% VSGP
mu_vsgp = .3;
beta_vsgp = 1;
log_vsgp = zeros(niters, 1);
log_vsgp_x = zeros(niters, N-1);
x = x0;
for k = 1:niters
    log_vsgp(k) = f(x);
    log_vsgp_x(k, :) = x;

    s_vsgp = H_complex(2:end, 2:end) * x + H_complex(2:end, 1);
    temp = norm(s_vsgp)^2 / (s_vsgp' * H_complex(2:end, 2:end) * s_vsgp);
    alpha_vspg = beta_vsgp * temp;
    for t = 1:20
        x_new = exp(1j*angle(x-alpha_vspg*s_vsgp));
        if f(x_new) < log_vsgp(k)
            break;
        else
            alpha_vspg = mu_vsgp * alpha_vspg;
        end
    end
    x = x_new;
    beta_vsgp = (beta_vsgp + mu_vsgp^(t - 1)) / 2;
end
x_vsgp = [1; x];
y_vsgp = Phi * x_vsgp;
c_vsgp = (y' * y_vsgp) / (y' * y);
y_vsgp = y_vsgp / c_vsgp;

%% VSGP 2
mu_vsgp2 = .8;
beta_vsgp = 1;
log_vsgp2 = zeros(niters, 1);
log_vsgp_x2 = zeros(niters, N-1);
x = x0;
for k = 1:niters
    log_vsgp2(k) = f(x);
    log_vsgp_x2(k, :) = x;

    s_vsgp = H_complex(2:end, 2:end) * x + H_complex(2:end, 1);
    temp = norm(s_vsgp)^2 / abs(s_vsgp'*H_complex(2:end, 2:end)*s_vsgp);
    alpha_vspg2 = beta_vsgp * temp;
    for t = 1:20
        x_new = exp(1j*angle(x-alpha_vspg2*s_vsgp));
        if f(x_new) < log_vsgp2(k)
            break;
        else
            alpha_vspg2 = mu_vsgp2 * alpha_vspg2;
        end
    end
    x = x_new;
    beta_vsgp = (beta_vsgp + mu_vsgp^(t - 1)) / 2;
end
x_vsgp2 = [1; x];
y_vsgp2 = Phi * x_vsgp2;
c_vsgp2 = (y' * y_vsgp2) / (y' * y);
y_vsgp2 = y_vsgp2 / c_vsgp2;

%% Compute rate
[M1, N1] = size(A_complex);
Re = real(A_complex);
Im = imag(A_complex);
A = [Re, -Im; Im, Re];
idx_M = reshape([1:M1; M1 + 1:2 * M1], 2*M1, 1);
idx_N = reshape([1:N1; N1 + 1:2 * N1], 2*N1, 1);
A = A(idx_M, idx_N);
b = [real(b_complex), imag(b_complex)];
b = b(idx_M);
x_star = [real(x_star_complex), imag(x_star_complex)];
x_star = x_star(idx_N);
X2 = reshape(x_star, 2, []);

rx = A' * (A * x_star - b);
Rx2 = reshape(rx, 2, []);
gm = sum(X2.*Rx2);

%% Alternative ways to compute gamma
err_KKT = norm(Rx2-gm.*X2, 'fro')
V2 = [-X2(2, :); X2(1, :)];
Vc = mat2cell(V2, 2, ones(1, N1));
Z = blkdiag(Vc{:});
H = (Z' * A') * (A * Z) - diag(gm);
lH = sort(eig(H), 'desc');

eta = 1 / L;
M_eta = eye(N1) - eta * (1 - eta * gm).^(-1) .* H;
lM = sort(eig(M_eta), 'desc');
rho_M_1L = lM(1)

eta_opt_H = 2 / (max(lH) + min(lH));
eta_array = linspace(0, 2*eta_opt_H, 1e4);
rho_array = zeros(size(eta_array));
for i = 1:length(eta_array)
    eta = eta_array(i);
    M_eta = eye(N1) - eta * (1 - eta * gm).^(-1) .* H;
    rho_array(i) = max(abs(eig(M_eta)));
end
% optimal step size
[rho_opt, eta_idx] = min(rho_array);
eta_opt = eta_array(eta_idx)

%% fixed step size
eta = 1 / L;
log_1L = zeros(niters, 1);
log_1L_x = zeros(niters, N-1);
x = x0;
for k = 1:niters
    log_1L(k) = f(x);
    log_1L_x(k, :) = x;

    df = H_complex(2:end, 2:end) * x + H_complex(2:end, 1);
    x = exp(1j*angle(x-eta*df));
end
x_1L = [1; x];
y_1L = Phi * x_1L;
c_1L = (y' * y_1L) / (y' * y);
y_1L = y_1L / c_1L;

%% Plot convergence
marker_spacing = 3000;
fig(1, 'border', 'on')
err = log_1L_x - log_nag_x(end, :);
semilogy(sqrt(sum(err.*conj(err), 2)), '-o', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2)
hold on
err = log_vsgp_x - log_nag_x(end, :);
semilogy(sqrt(sum(err.*conj(err), 2)), '-x', 'MarkerIndices', 150:marker_spacing:niters, 'LineWidth', 2)
err = log_vsgp_x2 - log_nag_x(end, :);
semilogy(sqrt(sum(err.*conj(err), 2)), '-s', 'MarkerIndices', 150:marker_spacing:niters, 'LineWidth', 2)
err = log_bt_x - log_nag_x(end, :);
semilogy(sqrt(sum(err.*conj(err), 2)), '-p', 'MarkerIndices', 150:marker_spacing:niters, 'LineWidth', 2)
err = log_nag_x - log_nag_x(end, :);
semilogy(sqrt(sum(err.*conj(err), 2)), '->', 'MarkerIndices', 1:marker_spacing/6:niters, 'LineWidth', 2)
set(gca, 'ColorOrderIndex', 1)
semilogy(1:niters, 1e3*rho_M_1L.^(1:niters), '--', 'LineWidth', 2)
set(gca, 'ColorOrderIndex', 4)
semilogy(1:niters, 1e3*rho_opt.^(1:niters), '--', 'LineWidth', 2)
hold off
set(gca, 'YScale', 'log')
ylim([1e-12, 1e4])
xlabel('$k$', 'interpreter', 'latex')
ylabel('$||x^{(k)}-\hat{x}||$', 'interpreter', 'latex')
legend('fixed $\eta=1/||A||_2^2$', ...
    'VSGP $\mu=0.3$', 'VSGP $\mu=0.8$', ...
    'Bt-PGD $\alpha=\beta=.8$ (this work)', ...
    'ARNAPGD $\alpha=\beta=.8$ (this work)', ...
    'interpreter', 'latex', 'location', 'best')


fig(2, 'border', 'on')
plot(alpha_mm/pi, y, 'x-', 'LineWidth', 2)
hold on
plot(alpha_mm/pi, abs(y_nag), 'LineWidth', 2)
hold off
legend('$y_m$', '$\hat{y}_m$', ...
    'interpreter', 'latex', 'location', 'best')
xlabel('$\theta/\pi$', 'Interpreter', 'latex')
ylabel('$|w^H a(\theta_m)|$', 'Interpreter', 'latex')
