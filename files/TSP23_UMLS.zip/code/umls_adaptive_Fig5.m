%%% Trung Vu - 03/20223

clear
load('data.mat')

%% Analyze rho as function of eta
eta_opt_H = 2 / (max(lH) + min(lH));
eta_array = [linspace(0, eta_opt_H, 1e4), linspace(eta_opt_H, 2.44, 1e4), ...
    linspace(2.44, 2*eta_opt_H, 1e4)];
rho_array = zeros(size(eta_array));
for i = 1:length(eta_array)
    eta = eta_array(i);
    M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
    rho_array(i) = max(abs(eig(M_eta)));
end
% optimal step size
[rho_opt, eta_idx] = min(rho_array);
eta_opt = eta_array(eta_idx);

%% Algorithm
niters = 1e5;
x0 = projection(x_star+1e-3*randn(2*N, 1));

%% fixed 1/L
eta = 1 / L;
M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
lM = sort(eig(M_eta), 'desc');
rho_M_1L = max(abs(lM));
assert(rho_M_1L < 1, ...
    'spectral radius of M is greater than 1');
logx_1L = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_1L(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% Fixed optimal
eta = eta_opt;
logx_opt = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_opt(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% Backtracking
alpha_bt = .8;
beta_bt = .8;
eta_bt = 1;
logx_bt = zeros(niters, 1);
log_count_bt = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_bt(k) = norm(x-x_star);

    count = 2;
    dg = A' * (A * x - b);
    while 1
        x_new = projection(x-eta_bt*dg);
        dG = (x - x_new) / eta_bt;

        % reduced
        if ((dG' * A') * (A * dG)) / (dG' * dG) <= 1 / eta_bt
            break;
        end

        eta_bt = eta_bt * beta_bt;
        count = count + 1;
    end
    log_count_bt(k) = count;
    x = x_new;
    eta_bt = eta_bt / alpha_bt;
end

%% NAG - AR (with backtracking)
logx_nag = zeros(niters, 1);
log_count_nag = zeros(niters, 1);
rho_nag = 1 - 2 / (1 + sqrt(2/(1 - rho_opt)-1));
x = x0;
y = x;
eta = 1;
theta_nag = 1;
alpha_nag = .8;
beta_nag = .8;
q = 0;
for k = 1:niters
    logx_nag(k) = norm(x-x_star);

    % backtracking alpha
    count = 2;
    df = A' * (A * y - b);
    while 1
        x_new = projection(y-eta*df);
        dG = (y - x_new) / eta;

        % reduced
        if ((dG' * A') * (A * dG)) / (dG' * dG) <= 1 / eta
            break;
        end

        eta = eta * beta_nag;
        count = count + 1;
    end
    log_count_nag(k) = count;
    eta = eta / alpha_nag;

    theta_nag_new = .5 * (q - theta_nag^2 + sqrt((theta_nag^2 - q)^2+4*theta_nag^2));
    beta = theta_nag * (1 - theta_nag) / (theta_nag^2 + theta_nag_new);
    dx = x_new - x;
    y_new = x_new + beta * dx;
    x = x_new;
    theta_nag = theta_nag_new;

    dg = y - x_new;
    if dg' * dx > 0 % gradient scheme
        theta_nag = 1;
    end
    y = y_new;
end


%% Plot convergence
marker_spacing = 600;
fig(1, 'border', 'on')
semilogy(logx_1L, '-o', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2)
hold on
semilogy(logx_opt, '-x', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2)
semilogy(logx_bt, '-s', 'MarkerIndices', 150:marker_spacing:niters, 'LineWidth', 2)
semilogy(logx_nag, '->', 'MarkerIndices', 1:marker_spacing/6:niters, 'LineWidth', 2)
set(gca, 'ColorOrderIndex', 1)
semilogy(1:niters, logx_opt(1)*rho_M_1L.^(1:niters), '--', 'LineWidth', 2)
semilogy(1:niters, logx_opt(1)*rho_opt.^(1:niters), '--', 'LineWidth', 2)
set(gca, 'ColorOrderIndex', 3)
hold off
ylim([1e-12, 1])
xlabel('$k$', 'interpreter', 'latex')
ylabel('$||x^{(k)}-x^*||$', 'interpreter', 'latex')
legend('fixed $\eta=1/||A||_2^2$', ...
    'fixed optimal $\eta^*$ (this work)', ...
    'Bt-PGD $\alpha=\beta=.8$ (this work)', ...
    'ARNAPGD $\alpha=\beta=.8$ (this work)', ...
    'interpreter', 'latex', 'location', 'best')
