%%% Trung Vu - 03/20223

clear
load('data.mat')

%% Analyze rho as function of eta
eta_opt_H = 2 / (max(lH) + min(lH));
eta_array = [linspace(0, eta_opt_H, 1e4), linspace(eta_opt_H, 2.44, 1e4), ...
    linspace(2.44, 2*eta_opt_H, 1e4)];
rho_array = zeros(size(eta_array));
for i = 1:length(eta_array)
    eta = eta_array(i);
    M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
    rho_array(i) = max(abs(eig(M_eta)));
end
% optimal step size
[rho_opt, eta_idx] = min(rho_array);
eta_opt = eta_array(eta_idx);

%% Algorithm
niters = 1e5;
x0 = projection(x_star+1e-3*randn(2*N, 1));
eta_0 = 1;

%% Fixed optimal
eta = eta_opt;
logx_opt = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_opt(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% Backtracking 1
alpha_bt = 1;
beta_bt = .8;
eta_bt = eta_0;
logx_bt = zeros(niters, 1);
log_count_bt = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_bt(k) = norm(x-x_star);

    count = 2;
    dg = A' * (A * x - b);
    while 1
        x_new = projection(x-eta_bt*dg);
        dG = (x - x_new) / eta_bt;

        % reduced
        if ((dG' * A') * (A * dG)) / (dG' * dG) <= 1 / eta_bt
            break;
        end

        eta_bt = eta_bt * beta_bt;
        count = count + 1;
    end
    log_count_bt(k) = count;
    x = x_new;
    eta_bt = eta_bt / alpha_bt;
end

%% Backtracking 2
alpha_bt = .8;
beta_bt = .8;
eta_bt = eta_0;
logx_bt2 = zeros(niters, 1);
log_count_bt2 = zeros(niters, 1);
log_eta = size(niters, 1);
x = x0;
for k = 1:niters
    logx_bt2(k) = norm(x-x_star);
    log_eta(k) = eta_bt;

    count = 2;
    dg = A' * (A * x - b);
    while 1
        x_new = projection(x-eta_bt*dg);
        dG = (x - x_new) / eta_bt;

        % reduced
        if ((dG' * A') * (A * dG)) / (dG' * dG) <= 1 / eta_bt
            break;
        end

        eta_bt = eta_bt * beta_bt;
        count = count + 1;
    end
    log_count_bt2(k) = count;
    x = x_new;
    eta_bt = eta_bt / alpha_bt;
end

%% Backtracking 3
alpha_bt = .5;
beta_bt = .8;
eta_bt = eta_0;
logx_bt3 = zeros(niters, 1);
log_count_bt3 = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_bt3(k) = norm(x-x_star);

    count = 2;
    dg = A' * (A * x - b);
    while 1
        x_new = projection(x-eta_bt*dg);
        dG = (x - x_new) / eta_bt;

        % reduced
        if ((dG' * A') * (A * dG)) / (dG' * dG) <= 1 / eta_bt
            break;
        end

        eta_bt = eta_bt * beta_bt;
        count = count + 1;
    end
    log_count_bt3(k) = count;
    x = x_new;
    eta_bt = eta_bt / alpha_bt;
end

%% Backtracking 4
alpha_bt = .1;
beta_bt = .8;
eta_bt = eta_0;
logx_bt4 = zeros(niters, 1);
log_count_bt4 = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_bt4(k) = norm(x-x_star);

    count = 2;
    dg = A' * (A * x - b);
    while 1
        x_new = projection(x-eta_bt*dg);
        dG = (x - x_new) / eta_bt;

        % reduced
        if ((dG' * A') * (A * dG)) / (dG' * dG) <= 1 / eta_bt
            break;
        end

        eta_bt = eta_bt * beta_bt;
        count = count + 1;
    end
    log_count_bt4(k) = count;
    x = x_new;
    eta_bt = eta_bt / alpha_bt;
end

%% Backtracking 5
alpha_bt = .01;
beta_bt = .8;
eta_bt = eta_0;
logx_bt5 = zeros(niters, 1);
log_count_bt5 = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_bt5(k) = norm(x-x_star);

    count = 2;
    dg = A' * (A * x - b);
    while 1
        x_new = projection(x-eta_bt*dg);
        dG = (x - x_new) / eta_bt;

        % reduced
        if ((dG' * A') * (A * dG)) / (dG' * dG) <= 1 / eta_bt
            break;
        end

        eta_bt = eta_bt * beta_bt;
        count = count + 1;
    end
    log_count_bt5(k) = count;
    x = x_new;
    eta_bt = eta_bt / alpha_bt;
end

%% Plot convergence
marker_spacing = 400;

fig(1, 'border', 'on')
semilogy(logx_opt, '--v', 'MarkerIndices', 200:marker_spacing:niters, 'LineWidth', 2)
hold on
semilogy(logx_bt, '-o', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2)
semilogy(logx_bt2, '-x', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2)
semilogy(logx_bt3, '-h', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2)
semilogy(logx_bt4, '-s', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2)
semilogy(logx_bt5, '-p', 'MarkerIndices', 200:marker_spacing:niters, 'LineWidth', 2)
hold off
ylim([1e-13, 1])
xlim([0, 1e4])
% grid on
xlabel('$k$', 'interpreter', 'latex')
ylabel('$||x^{(k)}-x^*||$', 'interpreter', 'latex')
legend('fixed optimal $\eta^*$', 'Bt-PGD $\alpha=1$', ...
    'Bt-PGD $\alpha=.8$', ...
    'Bt-PGD $\alpha=.5$', 'Bt-PGD $\alpha=.1$', ...
    'Bt-PGD $\alpha=.05$', ...
    'interpreter', 'latex', 'location', 'best')


fig(2, 'border', 'on')
marker_indices = round(logspace(0, log10(niters), 10));
marker_indices2 = round(logspace(1, log10(niters), 10));
loglog(2*(1:niters), '--v', 'MarkerIndices', marker_indices2, 'LineWidth', 2)
hold on
loglog(cumsum(log_count_bt), '-o', 'MarkerIndices', marker_indices, 'LineWidth', 2)
loglog(cumsum(log_count_bt2), '-x', 'MarkerIndices', marker_indices, 'LineWidth', 2)
loglog(cumsum(log_count_bt3), '-h', 'MarkerIndices', marker_indices, 'LineWidth', 2)
loglog(cumsum(log_count_bt4), '-s', 'MarkerIndices', marker_indices, 'LineWidth', 2)
loglog(cumsum(log_count_bt5), '-p', 'MarkerIndices', marker_indices, 'LineWidth', 2)
hold off
% grid on
xlabel('$k$', 'interpreter', 'latex')
ylabel('\# of matrix-vector products', 'interpreter', 'latex')
legend('fixed optimal $\eta^*$', 'Bt-PGD $\alpha=1$', ...
    'Bt-PGD $\alpha=.8$', ...
    'Bt-PGD $\alpha=.5$', 'Bt-PGD $\alpha=.1$', ...
    'Bt-PGD $\alpha=.05$', ...
    'interpreter', 'latex', 'location', 'best')


fig(3, 'border', 'on')
marker_indices = 1:marker_spacing:niters;
marker_indices2 = 200:marker_spacing:niters;
semilogy(2*(1:niters), logx_opt, '--v', 'MarkerIndices', marker_indices2, 'LineWidth', 2)
hold on
semilogy(cumsum(log_count_bt), logx_bt, '-o', 'MarkerIndices', marker_indices, 'LineWidth', 2)
semilogy(cumsum(log_count_bt2), logx_bt2, '-x', 'MarkerIndices', marker_indices, 'LineWidth', 2)
semilogy(cumsum(log_count_bt3), logx_bt3, '-h', 'MarkerIndices', marker_indices, 'LineWidth', 2)
semilogy(cumsum(log_count_bt4), logx_bt4, '-s', 'MarkerIndices', marker_indices, 'LineWidth', 2)
semilogy(cumsum(log_count_bt5), logx_bt5, '-p', 'MarkerIndices', marker_indices, 'LineWidth', 2)
hold off
% grid on
ylim([1e-13, 1])
xlabel('\# of matrix-vector products', 'interpreter', 'latex')
ylabel('$||x^{(k)}-x^*||$', 'interpreter', 'latex')
legend('fixed optimal $\eta^*$', 'Bt-PGD $\alpha=1$', ...
    'Bt-PGD $\alpha=.8$', ...
    'Bt-PGD $\alpha=.5$', 'Bt-PGD $\alpha=.1$', ...
    'Bt-PGD $\alpha=.05$', ...
    'interpreter', 'latex', 'location', 'best')


fig(4, 'border', 'on')
plot(1:niters, log_eta)
hold on
plot(1:niters, eta_opt*ones(niters, 1), '--', 'LineWidth', 2)
hold off
xlabel('$k$', 'interpreter', 'latex')
ylabel('$\eta_k$', 'interpreter', 'latex')
xlim([1, 2e4])
ylim([1, 7])
% grid on
[p, z1] = zoomPlot(1:niters, log_eta, [5800, 6000], [0.4, 0.6, 0.4, 0.3], [1, 3]);
hold on
plot(1:niters, eta_opt*ones(niters, 1), '--', 'LineWidth', 2)
hold off
legend hide
z1.LineWidth = 1.5;
legend('$\eta_k$', ['$\eta^*=$', num2str(eta_opt)], 'interpreter', 'latex', 'location', 'best')
