%%% Trung Vu - 03/20223

clear
load('data.mat')

%% Plot rho as function of eta
eta_opt_H = 2 / (max(lH) + min(lH));
eta_array = [linspace(0, eta_opt_H, 1e4), linspace(eta_opt_H, 2.44, 1e4), ...
    linspace(2.44, 2*eta_opt_H, 1e4)];
rho_linear_array = max(abs(1-eta_array*max(lH)), abs(1-eta_array*min(lH)));
rho_linear_array2 = max(abs(1-eta_array*max(lH)./(1 - eta_array * max(gm))), ...
    abs(1-eta_array*min(lH)./(1 - eta_array * max(gm))));
rho_linear_array3 = max(abs(1-eta_array*min(lH)./(1 - eta_array * min(gm))), ...
    abs(1-eta_array*max(lH)./(1 - eta_array * min(gm))));
rho_array = zeros(size(eta_array));
for i = 1:length(eta_array)
    eta = eta_array(i);
    M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
    rho_array(i) = max(abs(eig(M_eta)));
end

% optimal step size
[rho_opt, eta_idx] = min(rho_array);
eta_opt = eta_array(eta_idx);

% maximum step size
eta_idx = find(rho_array(2:end) >= 1, 1);
eta_max = eta_array(eta_idx);
rho_max = rho_array(eta_idx);

%% Algorithm
niters = 1e5;
x0 = projection(x_star+1e-3*randn(2*N, 1));

%% fixed 1/L
eta = 1 / L;
M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
lM = sort(eig(M_eta), 'desc');
rho_M_1L = max(abs(lM));
assert(rho_M_1L < 1, ...
    'spectral radius of M is greater than 1');
logx_1L = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_1L(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% fixed max
eta = eta_max;
logx_max = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_max(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% fixed sub-optimal
eta_opt_sub = 2 / (max(lH) + min(lH));
rho_opt_sub_est = (max(lH) - min(lH)) / (max(lH) + min(lH));
eta = eta_opt_sub;
M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
lM = sort(eig(M_eta), 'desc');
rho_opt_sub = max(abs(lM));
assert(rho_M_1L < 1, ...
    'spectral radius of M is greater than 1');
logx_opt_sub = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_opt_sub(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% fixed 0.05
eta_05 = .05;
eta = eta_05;
M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
lM = sort(eig(M_eta), 'desc');
rho_05 = max(abs(lM));
assert(rho_M_1L < 1, ...
    'spectral radius of M is greater than 1');
logx_05 = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_05(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% fixed 0.2
eta_2 = .2;
eta = eta_2;
M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
lM = sort(eig(M_eta), 'desc');
rho_2 = max(abs(lM));
assert(rho_M_1L < 1, ...
    'spectral radius of M is greater than 1');
logx_2 = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_2(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% fixed 0.4
eta_4 = .4;
eta = eta_4;
M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
lM = sort(eig(M_eta), 'desc');
rho_4 = max(abs(lM));
assert(rho_M_1L < 1, ...
    'spectral radius of M is greater than 1');
logx_4 = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_4(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% over step 1
eta_over = 1.01 * eta_max;
eta = eta_over;
M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
lM = sort(eig(M_eta), 'desc');
rho_over = max(abs(lM));
assert(rho_M_1L < 1, ...
    'spectral radius of M is greater than 1');
logx_over = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_over(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% over step 2
eta_over2 = 1.1 * eta_max;
eta = eta_over2;
M_eta = eye(N) - eta * (1 - eta * gm).^(-1) .* H;
lM = sort(eig(M_eta), 'desc');
rho_over2 = max(abs(lM));
assert(rho_M_1L < 1, ...
    'spectral radius of M is greater than 1');
logx_over2 = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_over2(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% fixed optimal
eta = eta_opt;
logx_opt = zeros(niters, 1);
x = x0;
for k = 1:niters
    logx_opt(k) = norm(x-x_star);

    x = projection(x-eta*A'*(A * x - b));
end

%% Plot convergence
marker_spacing = 3000;
fig(1, 'border', 'on')
g1 = semilogy(logx_max, '-o', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 1);
hold on
g2 = semilogy(logx_over, '-x', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 1);
g3 = semilogy(logx_over2, '-*', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 1);
g4 = semilogy(logx_05, '-s', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2);
g5 = semilogy(logx_2, '-d', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2);
g6 = semilogy(logx_4, '-p', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2);
g7 = semilogy(logx_1L, '-v', 'MarkerIndices', 1:marker_spacing:niters, 'LineWidth', 2);
g8 = semilogy(logx_opt, '-h', 'MarkerIndices', 1:marker_spacing/4:niters, 'LineWidth', 2);
set(gca, 'ColorOrderIndex', 1)
semilogy(1:niters, 10*logx_max(1)*rho_max.^(1:niters), '--', 'LineWidth', 2);
set(gca, 'ColorOrderIndex', 4)
semilogy(1:niters, 10*logx_05(1)*rho_05.^(1:niters), '--', 'LineWidth', 2)
semilogy(1:niters, 10*logx_2(1)*rho_2.^(1:niters), '--', 'LineWidth', 2)
semilogy(1:niters, 10*logx_4(1)*rho_4.^(1:niters), '--', 'LineWidth', 2)
semilogy(1:niters, 10*logx_1L(1)*rho_M_1L.^(1:niters), '--', 'LineWidth', 2);
semilogy(1:niters, 10*logx_opt(1)*rho_opt.^(1:niters), '--', 'LineWidth', 2)
hold off
ylim([1e-12, 1e2])
xlabel('$k$', 'interpreter', 'latex')
ylabel('$||x^{(k)}-x^*||$', 'interpreter', 'latex')
legend([g4, g5, g6, g7, g8], '$\eta=0.05$', '$\eta=0.2$', '$\eta=0.4$', ...
    ['$\eta=', num2str(1/L), '=1/||A||_2^2$'], ...
    ['$\eta^*=', num2str(eta_opt), '$'], ...
    'interpreter', 'latex', 'location', 'best')
a = axes('position', get(gca, 'position'), 'visible', 'off');
legend(a, [g1, g2, g3], ['$\eta_{\max}=', num2str(eta_max), '$'], ...
    '$1.01 \eta_{\max}$', '$1.1 \eta_{\max}$', ...
    'interpreter', 'latex', 'location', 'best')

fig(2, 'border', 'on')
plot(eta_array, rho_array, 'LineWidth', 2);
hold on
yline(1, 'k--', 'LineWidth', 2)
plot(eta_opt, rho_opt, 'bh', 'MarkerSize', 5, 'LineWidth', 3)
plot(eta_max, rho_max, 'b*', 'MarkerSize', 10, 'LineWidth', 2)
plot([0, eta_opt], [1, rho_opt], '--')
hold off
ylim([0.991, 1.005])
xlim([0, 3])
grid on
xlabel('$\eta$', 'interpreter', 'latex')
ylabel('$\rho(M_\eta)$', 'interpreter', 'latex')

