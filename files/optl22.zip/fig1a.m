clear

t=(0.001:0.001:0.999)';
r=(0.001:0.001:0.999)';
[R,T]=meshgrid(r,t);
a1=expint(2*log(1./(R+(1-R).*T)))-expint(2*log(1./R));
a2=expint(log(1./(R+(1-R).*T)))-expint(log(1./R));
d=1+1/2./R.*log(log(1./R)./log(1./(R+(1-R).*T)));
a0=1./R.^2./log(1./R)./2.*(a1-R.*a2);
tg=a0+d;
    
figure(123)
[c,h]=contourf(R,T,tg,[0:5,10,15,20]);
% clabel(c,h,'manual')
clabel(c,h)
xlabel('$\rho$','interpreter','latex')
ylabel('$\tau$','interpreter','latex')
grid on
axis square