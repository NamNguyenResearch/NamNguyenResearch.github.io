close all
clear
t=0.89;
r=0.9;

%%%
dx=0.0001;
x=0:dx:log(1e4);    % epsilon = 1e-6
v=r+(1-r)*t;
c1=1/2/r*log(log(r)/log(v))+1;
c2=1/log(1/r)/r*(expint(log(1/v))-expint(log(1/r)));

Kmax=ceil(x(end)/log(1/r)+c2);
dvec=zeros(1,Kmax+1);
d=0;
for i=1:Kmax
    d=d-log(r+(1-r)*t*exp(-d));
    dvec(i+1)=d;
end
K_vec = interp1(dvec, 0:(Kmax), x,'next');
f=-1./log(r+(1-r)*t*exp(-x));
F=cumsum(f)*dx;
F=[0,F(1:end-1)];
Fbnd1=x/log(1/r)+1/log(1/r)/r*(expint(log(1/v))-expint(log(1./(r+(1-r)*t*exp(-x)))));

fig(1)
semilogx(exp(x),K_vec,'.')
hold on
semilogx(exp(x),F,...
    exp(x),F+c1,...
    exp(x),Fbnd1+c1,...
    exp(x),x/log(1/r)+c1+c2,... 
    'LineWidth',1);
grid on
xlabel('$1/\epsilon$','interpreter','latex')
ylabel('$K(\epsilon)$ and its bounds','interpreter','latex')
lg=legend('$K(\epsilon)$', '$\underline{K}(\epsilon)$', '$\overline{K}(\epsilon)$', ...
    '$\overline{K}_1(\epsilon)$', '$\overline{K}_2(\epsilon)$', ... 
    'interpreter','latex','location','best','AutoUpdate','off');
pos = get(lg,'Position');
set(lg,'Position',[.47 .17 pos(3) pos(4)]);


%% Zoom 1
[p,z1]=zoomPlot(exp(x),K_vec,[1.1 1.6],[0.17 0.65 0.2 0.2],[1,3]);
hold on
semilogx(exp(x),F,...
    exp(x),F+c1,...
    exp(x),Fbnd1+c1,...
    exp(x),x/log(1/r)+c1+c2,...
    'LineWidth',2);
legend hide
z1.LineWidth = 1.5;


%% Zoom 2
axes(p)
[p,z2]=zoomPlot(exp(x),K_vec,[2e3 3e3],[0.73 0.38 0.2 0.2],[1,3]);
hold on
semilogx(exp(x),F,...
    exp(x),F+c1,...
    exp(x),Fbnd1+c1,...
    exp(x),x/log(1/r)+c1+c2,... 
    'LineWidth',2);
legend hide
z2.LineWidth = 1.5;


%% Zoom 3
axes(p)
[p,z3]=zoomPlot(exp(x),K_vec,[22 38],[0.45 0.75 0.2 0.2],[1,3]);
hold on
semilogx(exp(x),F,...
    exp(x),F+c1,...
    exp(x),Fbnd1+c1,...
    exp(x),x/log(1/r)+c1+c2,... 
    'LineWidth',2);
legend hide
z3.LineWidth = 1.5;

axes(z1)
axes(z2)
axes(z3)
hold off







